package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@org.springframework.stereotype.Service
public interface Service {

	public Users createUser(Users user) throws UserAlreadyExistException;
	
	public String deleteUser(int userId) throws UserDoesNotExistException;
	
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException;
	
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException;
	
	public String clearCart();
	
	public Map<Integer, Cart> addABookToCart(Book book);
	
	public Map<Integer, Cart> removeABookFromCart(int cartId) throws BookDoesNotExistException;
	
	public Map<Integer, Cart> addQuantityOfBook(int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException;
	
	public Map<Integer, Cart> decreaseQuantityOfBook(int cartId);
	
	public List<Users> listAllUsers();
	
	public List<RegisterCustomer> listAllCutomers();
	
	public Map<Integer, Cart> showCart() throws NoBookInTheCartException;
}
