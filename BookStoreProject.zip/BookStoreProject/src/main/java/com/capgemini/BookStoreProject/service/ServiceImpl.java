package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.dao.BookDAO;
import com.capgemini.BookStoreProject.dao.CustomerCartManagement;
import com.capgemini.BookStoreProject.dao.CustomerCartManagementImpl;
import com.capgemini.BookStoreProject.dao.CustomerDAO;
import com.capgemini.BookStoreProject.dao.UserDAO;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service {

	@Autowired
	UserDAO userDAO;
	
	@Autowired
	CustomerDAO customerDAO;
	
	@Autowired
	BookDAO bookDAO;
	
	CustomerCartManagement customerCartMgmt = new CustomerCartManagementImpl();
	@Override
	public Users createUser(Users user) throws UserAlreadyExistException {
	String email=user.getEmail();
	List<Users> userList=listAllUsers();
	for(Users list: userList)
	{
		if(!email.equals(list.getEmail())) {
			userDAO.save(user);
			return user;
		}
	}
	throw new UserAlreadyExistException("This user already exists");
	}
			

	@Override
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException {
		if(customerDAO.existsById(customer.getPhonenumber()))
		{
			customerDAO.save(customer);
			return customer;
		}
		else
			throw new CustomerAlreadyExistException("This customer already exist");
		
	}

	@Override
	public String clearCart() {
		customerCartMgmt.clearCart();
		return "Cart cleared successfully";
	}

	@Override
	public Map<Integer,Cart> addABookToCart(Book book) {
		Cart cart = customerCartMgmt.searchBook(book.getBookId());
		if(cart==null)
		{
			customerCartMgmt.addABookToCart(book);
			return customerCartMgmt.showAll();
		}
		else
		{
			cart.setQuantity(cart.getQuantity()+1);
			return customerCartMgmt.showAll();
		}
	}

	@Override
	public Map<Integer, Cart> removeABookFromCart(int cartId) throws BookDoesNotExistException {
		Cart cart = customerCartMgmt.searchBook(cartId);
		if(cart!=null)
		{
			customerCartMgmt.removeABookFromCart(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookDoesNotExistException("This book does not exist in your cart");
		
	}

	@Override
	public Map<Integer, Cart> addQuantityOfBook(int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException {
		Book bookSearch = bookDAO.findById(cartId).get();
		if((bookSearch.getQuantity()-1)>=0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()-1);
			customerCartMgmt.addQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookCannotBeAddedMoreAsItIsOutOfStockException("No more quantity of this Book can be added as it has become OUT OF STOCK");
	}

	@Override
	public String deleteUser(int userId) throws UserDoesNotExistException {
		if(userDAO.existsById(userId))
		{
			userDAO.deleteById(userId);
			return "User Deleted Successfully";
		}
		else
			throw new UserDoesNotExistException("This User does not exist");
	}

	@Override
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException {
		if(userDAO.existsById(userId))
		{
			userDAO.deleteById(userId);
			userDAO.save(updatedUser);
			return updatedUser;
		}
		else
			throw new UserDoesNotExistException("This user does not exist");
	}

	@Override
	public Map<Integer,Cart> decreaseQuantityOfBook(int cartId) {
		Book bookSearch = bookDAO.findById(cartId).get();
		Cart cart = customerCartMgmt.searchBook(cartId);
		if((cart.getQuantity()-1)==0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()+1);
			customerCartMgmt.removeABookFromCart(cartId);
			return customerCartMgmt.showAll();
		}
		else
			{customerCartMgmt.decreaseQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
			}
	}

	@Override
	public List<Users> listAllUsers() {
		
		return userDAO.findAll();
	}
	
	@Override
	public List<RegisterCustomer> listAllCutomers() {
		
		return customerDAO.findAll();
	}


	@Override
	public Map<Integer, Cart> showCart() throws NoBookInTheCartException {
		Map<Integer,Cart> bookCart = customerCartMgmt.showAll();
		if(bookCart.size()>0)
		{
		return customerCartMgmt.showAll();
		}
		else
			throw new NoBookInTheCartException("There is no book in the cart");
	}

}
