package com.capgemini.BookStoreProject.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;
import com.capgemini.BookStoreProject.service.ServiceImpl;

@RestController
public class BookStoreController {

	@Autowired
	ServiceImpl serviceImpl;
	
	
	@RequestMapping(value="/")
	public String home()
	{
		return "home";
	}
	@RequestMapping(value="/showAllUsers",method=RequestMethod.GET)
	public List<Users> showAllUsers()
	{
		return serviceImpl.listAllUsers();
	}
	
	@RequestMapping(value="/showAllCustomers",method=RequestMethod.GET)
	public List<RegisterCustomer> showAllCustomers()
	{
		return serviceImpl.listAllCutomers();
	}
	
	
	@RequestMapping(value="/createUser",method=RequestMethod.PUT)
	public Users createUser(@RequestBody Users user) throws UserAlreadyExistException
	{
		return serviceImpl.createUser(user);
	}
	
	@RequestMapping(value="/createCustomer",method=RequestMethod.PUT)
	public RegisterCustomer createCustomer(@RequestBody RegisterCustomer customer) throws CustomerAlreadyExistException
	{
		return serviceImpl.registerCustomer(customer);
	}
	
	@RequestMapping(value="/deleteUser/{id}",method=RequestMethod.DELETE)
	public String deleteUser(@PathVariable int id) throws UserDoesNotExistException
	{
		return serviceImpl.deleteUser(id);
	}
	
	@RequestMapping(value="/editUser/{id}",method=RequestMethod.PUT)
	public Users createUser(@PathVariable int id,@RequestBody Users user) throws UserDoesNotExistException
	{
		return serviceImpl.editUser(id, user);
	}
	
	@RequestMapping(value="/clearCart",method=RequestMethod.GET)
	public String clearCart()
	{
		return serviceImpl.clearCart();
	}
	
	@RequestMapping(value="/addABookToCart",method=RequestMethod.PUT)
	public Map<Integer,Cart> addABookToCart(@RequestBody Book book)
	{
		return serviceImpl.addABookToCart(book);
	}
	
	@RequestMapping(value="/removeABookFromCart/{id}",method=RequestMethod.DELETE)
	public Map<Integer,Cart> removeABookFromCart(@PathVariable int id) throws BookDoesNotExistException, NoBookInTheCartException
	{
		if(serviceImpl.showCart().size()==1)
			{
			serviceImpl.removeABookFromCart(id);
//			showCartMessage();
			}
		else
			return serviceImpl.removeABookFromCart(id);
		return null;
	}
	
//	@RequestMapping(value = "/showCartMessage")
//	private String showCartMessage() {
//		
//		return "Cart is emptied";
//	}
	@RequestMapping(value="/addQuantityOfBook/{id}",method=RequestMethod.PUT)
	public Map<Integer,Cart> addQuantityOfBook(@PathVariable int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException
	{
		return serviceImpl.addQuantityOfBook(cartId);
	}
	
	@RequestMapping(value="/decreaseQuantityOfBook/{id}",method=RequestMethod.PUT)
	public Map<Integer,Cart> decreaseQuantityOfBook(@PathVariable int id)
	{
		return serviceImpl.decreaseQuantityOfBook(id);
	}
	
	@RequestMapping(value="/showCart",method=RequestMethod.GET)
	public Map<Integer,Cart> showCart() throws NoBookInTheCartException
	{
		return serviceImpl.showCart();
	}
	
}

